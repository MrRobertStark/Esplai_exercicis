<?php
    $server = "localhost";
    $username = "root";
    $password = "";
    $database = "fundacioesplai_prova0";
    $conn = new mysqli($server,$username,$password,$database);
?>