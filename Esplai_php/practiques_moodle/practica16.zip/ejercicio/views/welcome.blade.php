    <!DOCTYPE html>
    <html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
        <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">

            <title>@yield('title_seo','La \'paradeta\' del senyor Panfiloberto')</title>

            <!-- Fonts -->
            <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

            <!-- Scripts -->
            <script src="{{ asset('js/app.js') }}" defer></script>

            <!-- Styles -->
            <link href="{{ asset('css/app.css') }}" rel="stylesheet">
            <style>
                *{
                    box-sizing:border-box;
                }
                html, body {
                    background-color: #fff;
                    color: #636b6f;
                    font-family: 'Nunito', sans-serif;
                    font-weight: 200;
                    height: 100%;
                    width:100%;
                    margin: 0;
                }

                .full-height {
                    height: 100%;
                    width:100%;
                }

                .flex-center {
                    float:left;
                }

                .position-ref {
                    position: relative;
                }

                .top-right {
                    position: absolute;
                    right: 10px;
                    top: 18px;
                }

                .content {
                    text-align: center;
                    margin:5em 0em;
                }

                .title {
                    font-size: 84px;
                }

                .links{
                    position:fixed;
                    width:100%;
                    top:0px;
                    left:50%;
                    margin-left:-50%;
                    padding:2em;
                    background-color:#292b2c;
                    text-align:center;
                }

                .links > a, .dropdown a {
                    color: white;
                    padding: 1em 3em;
                    font-size: 15px;
                    font-weight: 600;
                    letter-spacing: .1rem;
                    text-decoration: none;
                    text-transform: uppercase;
                    transition: background-color 0.3s;
                }
                .links > a:hover{
                    background-color:#e0e0e0;
                    color:#292b2c;
                }

                .m-b-md {
                    margin: 40px 30px;
                }
                .footer{
                    width:100%;
                    background-color: #292b2c;
                    position:absolute;
                    bottom:0px;
                    left:0px;
                    padding:1em;
                    text-align:center;
                    color:white;
                    font-size:14pt;
                }
            </style>
        </head>
        <body>
            <div class="d-flex align-items-center justify-content-center position-ref full-height">
                @if (Route::has('login'))
                    <div class="top-right links">
                        @auth
                            <a href="{{ url('/home') }}">Home</a>
                        @else
                            <a href="{{ route('login') }}">Login</a>

                            @if (Route::has('register'))
                                <a href="{{ route('register') }}">Register</a>
                            @endif
                        @endauth
                    </div>
                @endif

                @include('partials.menuFrontend')

                <div class="content">
                    <div class="title m-b-md">
                        Botiga online
                    </div>
                </div>
                
                @include('partials.footer')
            </div>
        </body>
    </html>
