<div class="links position-fixed fixed-top">
    <a href="{{route('quisom')}}">Qui som?</a>
    <a href="{{route('filosofia')}}">Filosofia</a>
    <a href="{{route('sostenibilitat')}}">Sostenibilitat</a>
    <a href="{{route('equip')}}">Equip</a>
    <a href="{{route('contacte')}}">Contacte</a>
    <!--Deplegable de categories-->
    <div class="dropdown show w-auto d-inline">
        <a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Categories
        </a>
        <!--Menu desplegable-->
        <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
            <!--Categories-->
            <a class="dropdown-item text-dark" href="{{route('categoria',['id'=>1])}}">Ecological Food</a>
            <a class="dropdown-item text-dark" href="{{route('categoria',['id'=>2])}}">Drinks</a>
        </div>
    </div>
</div>