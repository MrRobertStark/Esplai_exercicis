@extends('layouts.base')

    @section('title_seo')
    Empresa | Qui som?
    @endsection

    @section('titol')
        <div class="title">
            Sobre nosaltres
        </div>
    @endsection

    @section('contingut')

        <h2 class = "text-center">Hola {{$client}}!</h2>
        
        <div class = "container text-justify">
            <p>
                Lorem ipsum dolor sit amet consectetur, adipisicing elit. Recusandae tempora reprehenderit voluptates, consectetur, voluptatem aut quo deserunt maxime sit cupiditate error culpa perferendis? Consequatur, necessitatibus delectus harum et totam at.
                Eaque, explicabo qui excepturi atque laborum, hic repellat, et sed ad assumenda nemo blanditiis quas nihil. Hic animi, eaque dolores maxime possimus, blanditiis ipsam at assumenda ducimus perferendis excepturi in.
                Odio quas distinctio necessitatibus quis, repellendus ab corporis perferendis vel laboriosam consectetur perspiciatis, cum tenetur explicabo? Quisquam ea pariatur iste vel a exercitationem, vitae sed distinctio, mollitia dolore, omnis in.
                Placeat aliquam obcaecati dolor ullam, explicabo nisi accusantium vero suscipit deleniti eius velit ipsam similique excepturi quibusdam consequuntur repellendus architecto blanditiis modi fugit corporis eveniet quia nam labore eos? Corrupti?
                Nobis autem dolore atque debitis possimus illo aliquid suscipit quidem, distinctio iusto recusandae tempora in numquam delectus aspernatur earum temporibus fugiat ipsam nam, eum, unde architecto cupiditate. Blanditiis, earum maxime?
                A accusamus ut, pariatur cumque tempora incidunt inventore ratione harum deserunt. Repellat tempora, expedita numquam laboriosam temporibus et. Nemo officiis quasi, quod ducimus facere recusandae explicabo aspernatur doloribus nostrum suscipit.
            </p>

        </div>        
    @endsection
