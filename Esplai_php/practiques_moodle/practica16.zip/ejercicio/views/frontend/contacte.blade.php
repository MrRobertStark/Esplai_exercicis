@extends('layouts.base')
    @section('title_seo')
        Empresa | Contacte
    @endsection


    @section('titol')
                <div class="title m-b-md">
                    Contacte
                </div>

    @endsection
    
    @section('contingut')
                
                <div class = "container">
                    <p>
                        Lorem ipsum dolor sit amet consectetur, adipisicing elit. Recusandae tempora reprehenderit voluptates, consectetur, voluptatem aut quo deserunt maxime sit cupiditate error culpa perferendis? Consequatur, necessitatibus delectus harum et totam at.
                        Repudiandae voluptate excepturi neque blanditiis quibusdam beatae numquam nulla facilis quos qui, quia, nesciunt reprehenderit impedit totam dolores eaque possimus esse exercitationem? Nostrum aspernatur impedit sequi quod! Inventore, veritatis. Consequuntur.
                        Nisi, laudantium! Dolorum veniam eos exercitationem, ad nihil corrupti minus incidunt provident iste rem. Inventore dolorem sed rem sapiente corporis labore iure tempore sunt omnis reprehenderit! Voluptatem non rerum hic.
                    </p>
                </div>

    @endsection