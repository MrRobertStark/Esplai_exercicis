@extends('layouts.base')

    @section('title_seo',"La paradeta d'en \"Panfiloberto\"")

    @section('titol')
        <div class = "title mt-n4">{{$producte->ProductName}}</div>
    @endsection

    @section('contingut')
    <div class = "container-fluid px-0">
        <div class = "card border border-white shadow-lg mb-5 p-4">
            <div class = "row">
                <div class="col col-12 col-md-7 col-lg-6 d-flex align-items-stretch justify-content-center p-0">
                    <!--CardHeader-->
                    <div class = "card-header d-flex align-items-center bg-white w-100 border border-white p-0">
                        <img src="{{$producte->UrlPhoto}}" alt="{{$producte->UrlPhoto}}" class = "card-img-top">
                    </div>
                </div>
                <div class="col col-12 col-md-5 col-lg-6 d-flex align-items-stretch">
                    <!--Cardbody-->
                    <div class = "card-body p-5 px-md-1 p-lg-5">
                        <h4 class = "card-subtitle text-center h1">Description</h4>
                        <p class = "mb-0 pb-0">
                            {{$producte->Description}}
                        </p>
                        <p>
                            Lorem ipsum dolor sit, amet consectetur adipisicing elit. Dolores, eaque molestias, nobis dolore aliquam obcaecati ullam beatae esse voluptate quod est accusamus impedit alias sint? Animi laboriosam adipisci culpa voluptates.
                        </p>
                        <p class = "text-center h1 pt-0">
                            {{number_format($producte->UnitPrice,2,',','.')}}€
                        </p>
                        <a href="{{route('categoria',['id'=>$producte->CategoryID])}}" class = "btn btn-primary mx-auto d-block w-75 py-3 more_products">Veure més productes</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    @endsection