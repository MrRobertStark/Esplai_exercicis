@extends('layouts.base')

    @section('title_seo')
    Alimentació
    @endsection

    @section('titol')
                <div class="title">
                    {{$categoria->categoryName}}
                </div>
    @endsection

    @section('contingut')
                
                <div class = "container px-0">
                    <p class = "text-center h2 my-3 py-0">
                        <b>{{$categoria->description}}</b>
                    </p>

                    <div class = "container-fluid my-5 px-0">
                        <div class = "row">
                        <?php                         
                            for($i = 0; $i < 3; $i++){
                                $producte = $productes[$i];
                            ?>
                                <div class = "col col-12 col-md-6 col-lg-4 d-flex align-items-stretch mx-auto">
                                    <div class = "card m-2 w-100 shadow-lg pb-5">
                                        <a href="{{route('producte',['id'=>$producte->id])}}">
                                            <img src="{{$producte->UrlPhoto}}" alt="" class = "card-img-top">
                                        </a>
                                        <div class = "card-body my-4">
                                            <h3 class = "card-title text-center mb-0">{{$producte->ProductName}}</h3>
                                            <p class = "card-text">{{$producte->Description}}</p>
                                            <p class = "card-text text-center h2 price">{{number_format($producte->UnitPrice,2,',','.')}}€</p>
                                            <a href="{{route('producte',['id'=>$producte->id])}}" class = "btn btn-success w-75 text-center link_prod">Veure producte</a>
                                        </div>
                                    </div>
                                </div>
                            <?php
                            }
                        ?>
                        </div>
                    </div>
                    
                </div>
                
    @endsection
