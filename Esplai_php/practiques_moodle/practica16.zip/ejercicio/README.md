Hi ha coses a tenir en compte:

1) Per estalviar memòria adjunto només al moodle els arxius que considero vitals per al funcionament de la pàgina web.
2) S'ha actualitzat i fet servir Bootstrap 4 per al projecte 'botiga'
3) S'ha inclòs: Controllers | Database (migrations) | models | routes | Views
4) Qualsevol cosa que falti per al seu funcionament o dubte, contactar!
5) Si calés un vídeo mostrant el seu funcionament, contactar!

Gràcies!