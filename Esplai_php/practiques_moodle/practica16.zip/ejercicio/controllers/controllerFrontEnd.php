<?php

namespace App\Http\Controllers;

use App\Category;
use App\Product;
use Illuminate\Http\Request;

class controllerFrontEnd extends Controller
{
    public function quisom(){
        $client = "Alberto Godofredo";
        return view('frontend.quisom',['client'=>$client]);
    }
    public function filosofia(){
        return view('frontend.filosofia');
    }
    public function sostenibilitat(){
        return view('frontend.sostenibilitat');
    }
    public function equip(){
        return view('frontend.equip');
    }
    public function contacte(){
        return view('frontend.contacte');
    }
    public function categoria($id){
        //Informació bàsica de la categoria
        $categoria = Category::find($id);

        //Productes amb la categoria $id
        if($id==1) $productes = [Product::find(2),Product::find(8),Product::find(9)];
        else $productes = [Product::find(3),Product::find(10),Product::find(11)];
        
        return view('frontend.categoria')
                ->with('categoria',$categoria)
                ->with('productes',$productes);
    }
    public function producte($id){
        $producte = Product::find($id);
        return view('frontend.detalls_producte')
            ->with('producte',$producte);
    }
}
