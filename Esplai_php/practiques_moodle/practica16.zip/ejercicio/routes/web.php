<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

ROUTE::prefix('empresa')->group(function(){
    ROUTE::get('quisom', 'controllerFrontend@quisom')->name('quisom');
    ROUTE::get('filosofia','controllerFrontend@filosofia')->name('filosofia');
    ROUTE::get('sostenibilitat','controllerFrontend@sostenibilitat')->name('sostenibilitat');
    ROUTE::get('equip','controllerFrontend@equip')->name('equip');
    ROUTE::get('contacte','controllerFrontend@contacte')->name('contacte');
});

ROUTE::get('categories/{id}','controllerFrontEnd@categoria')->name('categoria');
ROUTE::get('producte/{id}','controllerFrontEnd@producte')->name('producte');

